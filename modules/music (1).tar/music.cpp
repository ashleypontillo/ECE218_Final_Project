//=====[Libraries]=============================================================

#include "mbed.h"
#include "arm_book_lib.h"

//=====[Declaration of private defines]========================================

#define MOTOR_DUTY_CYCLE 0.5

//=====[Declaration of private data types]=====================================

digitalInOut musicPin(PE_11);

//=====[Declaration and initialization of public global objects]===============

//=====[Declaration of external public global variables]=======================

//=====[Declaration and initialization of private global variables]============

//=====[Declarations (prototypes) of private functions]========================
static void setPeriod(float period);

//=====[Implementations of public functions]===================================


//set period and duty cycle
void musicInit(){

}

void setDutyCycle(float dutyCycle)
{
    musicPin.write(dutyCycle);
}


//
static void setPeriod(float period)


//